AS PASTAS QUE ESTÃO "FALTANDO" SÃO APENAS AS PASTAS DE INSTALAÇÃO DE BIBLIOTECAS E COISAS ASSIM.
(NÃO FORAM INCLUÍDAS NO GITHUB POR SEREM PESADAS DEMAIS)

PARA RODAR O PROGRAMA APROPRIADAMENTE, INSTALE ESTAS BIBLIOTECAS NO SEU VSCODE:
(código para instala-las)

npm install @eslint/js
@types/react-dom
@types/react
@vitejs/plugin-react
eslint-plugin-react-hooks
eslint-plugin-react-refresh
eslint globals
react-dom
react-router-dom
react typescript-eslint
typescript
vite
