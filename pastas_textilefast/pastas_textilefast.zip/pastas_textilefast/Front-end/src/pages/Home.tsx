import { Navbar } from "../components/Navbar";
import { Destaques } from "../components/Destaques";

export function Home(){
    return(
        <>
            <Navbar />
            <Destaques />
        </>
    )
}

export default Home;