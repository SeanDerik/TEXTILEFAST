import Loginform from "../components/Loginform";

export function Loginformpage(){
    return(
        <>
            <Loginform />
        </>
    )
}

export default Loginformpage;