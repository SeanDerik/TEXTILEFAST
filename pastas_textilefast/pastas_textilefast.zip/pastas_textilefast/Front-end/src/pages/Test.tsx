import { Navbar } from "../components/Navbar";
import { Helloworld } from "../components/Helloworld";


export function Test(){
    return(
        <>
        <Navbar />
        <Helloworld />
        </>
    )
}