import { Login } from "../components/Login";

export function Loginpage() {
    return (
        <>
            <Login />
        </>
    );
}

export default Loginpage;
